<!DOCTYPE html>
<?php
session_start();
if(isset($_SESSION['usernamesession1']) && isset($_SESSION['passwordsession1'])){
    $user=$_SESSION['usernamesession1'];
    $pass=$_SESSION['passwordsession1'];
    
}
 else {
  echo "<meta http-equiv=\"refresh\" content=\"0;logout1.php\">";  
 }



 

?>
<html lang="en">
  <head>
  
  <script>
function Reg6()
{
	var numpattern = /^\d{2}$/;
	var namepattern = /^[a-zA-Z ]{2,30}$/;
	var descpattern = /^[a-zA-Z ]{5,300}$/;
	var msg="";
	// 	var busNum=document.getElementById("busNum").value;  
	var circularName=document.getElementById("circularName").value;
	var circularDesc=document.getElementById("circularDesc").value;

    	

	
	if(circularName==undefined || circularName=="")
		{
		msg=msg+"\nCircular Name cannot be blank";
		}
		
	if(!(circularName.match(namepattern)))
	     {
	     msg=msg+"\nCircular Name should be an alphabetic value";
	     }

	if(circularDesc==undefined || circularDesc=="")
		{
		msg=msg+"\nCircular Description cannot be blank";
		}
		
	if(!(circularDesc.match(descpattern)))
	     {
	     msg=msg+"\nCircular Description should be an alphabetic value";
	     }	 


	
		 
	if(msg!="")
		{
		alert(msg);
		return false;
		}
		
	//else
		//{
		//var details="Name: "+name+"<br>USN: "+usn+"<br>Gender: "+gender+"<br>Country: "+cou+"<br>State: "+st+"<br>City: "+ci+"<br>Hobbies: "+hobby+"<br>Branch: "+bran;
		//document.getElementById("print").innerHTML = details;
		//return false;
		//}	 
}	
</script>
  
  
  
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 
    Dragonfruit Template 
    http://www.templatemo.com/preview/templatemo_411_dragonfruit 
    -->
    <title>CIRCULAR</title>
    <meta name="description" content="" />
    <!-- templatemo 411 dragonfruit -->
    <meta name="author" content="templatemo">
    <!-- Favicon-->
    <link rel="shortcut icon" href="./favicon.png" />		
    <!-- Font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Camera -->
    <link href="css/camera.css" rel="stylesheet">
    <!-- Template  -->
    <link href="css/templatemo_style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style>
	
	.formbox 
	{
 align: center;
  background-color: #f2f2e5;
 width: 520px;
  padding: 20px;
  margin: 20px;
  
}
	
input[type=submit] {
    width: 8%;
	
    background-color: #333333;
    color: #fff;
    padding: 14px 80px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	
}


input[type=submit]:hover {
    background-color: #45a049;
}


select {
    width: 8%;
	 background-color: white;
    
    color: black;
    padding: 14px 120px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
	
}
#one{
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}

h5{

    
	 color:black;
}
h6{

    
	 color:white;
}
table {
position:absolute;
top:150px;
left:150px;

	width:80%;
   
}
input[type=text] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
input[type=number] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
button {
 background-color: #333333;
    width: 100%;
	color:white;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	border: 2px solid #66605E;
}
td, th {
  background-color: black;
  color:white;
    border: 1px solid white;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
 color:white;
    background-color: white;
}
	</style>
  </head>
<body>
<div  class="banner" id="templatemo_banner_slide">
    <ul>
        <li class="templatemo_banner_slide_01">
          <br><br><br>
           <h2 style="color:black; position:absolute; top:80px; left:500px;">ADD CIRCULAR DETAILS</h2>
	 <form method="post" style="color:black; position:absolute; top:150px; left:550px;" class="formbox">
   <h5><label for="lname">CIRCULAR NAME:</label></h5>
    <input type="text" id="circularName" name="cname" placeholder="Enter  circular name">
	<br>
	 <h5><label for="lname">DESCRIPTION :</label></h5>
    <input type="text" id="circularDesc" name="des" placeholder="Enter description">
	<br>
	 <h5><label for="lname">BUS NUMBER:</label></h5>
  <!-- <input type="number" id="busNum" name="busno" placeholder="Enter busno">-->
   
   <select class="form-control "name="busno">
                    <option value="">SELECT BUS</option>
					 <?php
					 include 'dbconfig.php';
                    $query="select * from busdetails";
					
                    $run=$conn->prepare($query);
                    $run->execute();
                    $rs=$run->get_result();
                    while ($res=$rs->fetch_assoc()) {
						
                    ?>
					
                    <option value="<?php echo $res["busno"];?>"><?php echo $res['busno']; ?></option>
					 <?php }?>
					
                </select>
	
	<br>
    
 
    <input type="submit" value="ADD" onclick="return Reg6()" id="register6">
  </form>
  <?php
                 include 'dbconfig.php';

       if (isset($_POST['cname']) && isset ($_POST['des']) && isset ($_POST['busno'])){
           $cname=$_POST['cname'];
           $des=$_POST['des'];
		   $busno=$_POST['busno'];
		   
          
           $sql = "INSERT INTO `circular` (`cname`, `des`, `busno`) VALUES ('$cname','$des','$busno')";
                     if(mysqli_query($conn, $sql))
                    {
                            
                            echo "<script type=\"text/javascript\">alert(\"Data Entered Successfully\");</script>";
                     }
               
                             
                
                else
               {
                   echo '<span style="color:red;">Insert all Attributes</a></span>';
               }
       }
      
        ?> 
	  
            
        </li>
        
    </ul>
	 <form method="post" action="logout1.php" style="color:black; position:absolute; top:30px; right:30px;" >
    <button type="submit" id="submit">LOGOUT</button>
  </form>
</div>

<div id="templatemo_mobile_menu">
        <ul class="nav nav-pills nav-stacked">
            <li><a rel="nofollow" href="index.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp;  SEARCH</a></li>
            <li><a rel="nofollow" href="bus.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; BUS DETAILS</a></li>
            <li><a rel="nofollow" href="route.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; ROUTE DETAILS</a></li>
            <li><a rel="nofollow" href="driver.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; DRIVER DETAILS</a></li>
            <li><a rel="nofollow" href="complaint.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; COMPLAINT</a></li>
            <li><a rel="nofollow" href="gallery.php" class="external-link"><i class="glyphicon glyphicon-export"></i> &nbsp; GALLERY</a></li>
        </ul>
</div>
<div class="container_wapper">
    <div id="templatemo_banner_menu">
        <div class="container-fluid">
            <div class="col-xs-4 templatemo_logo">
            	<a href="#">
                	<img src="images/logo.png" id="logo_img"  />
                
                </a>
            </div>
            <div class="col-sm-8 hidden-xs">
                <ul class="nav nav-justified">
                   
                    <li><a  href="busdetails.php" class="external-link">BUS DETAILS</a></li>
                    <li><a  href="routedetails.php" class="external-link">ROUTE DETAILS</a></li>
                    <li><a rel="nofollow" href="driverdetails.php" class="external-link">DRIVER DETAILS</a></li>
                    <li><a  href="viewcomplaint.php" class="external-link">VIEW COMPLAINT</a></li>
                    <li><a  href="circular.php" class="external-link">CIRCULAR</a></li>
                 </ul>
            </div>
            <div class="col-xs-8 visible-xs">
                <a href="#" id="mobile_menu"><span class="glyphicon glyphicon-th-list"></span></a>
            </div>
        </div>
    </div>
</div>
 <br><br>
		   
      

<div id="templatemo_footer">
    <div>
        <p id="footer"> CIT TRANSPORTATION</p>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.singlePageNav.min.js"></script>
<script src="js/unslider.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
<script src="js/templatemo_script.js"></script>
</body>
</html>