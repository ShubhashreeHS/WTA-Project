<?php
                 include 'dbconfig.php';

     
           $dname=$_GET['id'];
       
          $query1="select dname from driver";
	 if ($dname!=$query1)
	 {

           $sql = "delete from  `driver` where `dname`='$dname' ";
                     if(mysqli_query($conn, $sql))
                    {
                            
                            echo "<script type=\"text/javascript\">alert(\"Driver deleted\");</script>";
                            echo "<meta http-equiv=\"refresh\" content=\"0;updatedriver.php\">";  
                     }
	 
                             
                
                else
               {
                   echo "<script type=\"text/javascript\">alert(\"Driver cannot be deleted\");</script>";
                            echo "<meta http-equiv=\"refresh\" content=\"0;updatedriver.php\">";
               }
       }
	   else
               {
                   echo '<span style="color:red;">Driver is assigned</a></span>';
               }
     
        ?>  
